/* BASSMOD simple test, copyright (c) 1999-2004 Ian Luck.
=========================================================
Imports: libbassmod.dylib, Carbon.framework
*/

#include <Carbon/Carbon.h>
#include <stdio.h>
#include "bassmod.h"

static WindowPtr win;

/* display error messages */
void Error(char *es)
{
	char mes[200];
	sprintf(mes,"%s\n(error code: %d)",es,BASSMOD_ErrorGetCode());
//	MessageBox(win,mes,"Error",0);
}

ControlRef GetControl(int id)
{
	ControlRef cref;
	ControlID cid={0,id};
	GetControlByID(win,&cid,&cref);
	return cref;
}

void SetupControlHandler(int id, DWORD event, EventHandlerProcPtr proc)
{
	EventTypeSpec cspec={kEventClassControl,event};
	ControlRef cref=GetControl(id);
	InstallEventHandler(GetControlEventTarget(cref),NewEventHandlerUPP(proc),1,&cspec,cref,NULL);
}
    
DWORD GetFlags()
{
	DWORD flags=BASS_MUSIC_POSRESET; // stop notes when seeking
	DWORD i=GetControl32BitValue(GetControl(21));
	if (i==1) flags|=BASS_MUSIC_NONINTER; // no interpolation
	i=GetControl32BitValue(GetControl(22));
	if (i==2) flags|=BASS_MUSIC_RAMP; // ramping
	if (i==3) flags|=BASS_MUSIC_RAMPS; // "sensitive"
	i=GetControl32BitValue(GetControl(23));
	if (i==2) flags|=BASS_MUSIC_SURROUND; // surround
	if (i==3) flags|=BASS_MUSIC_SURROUND2; // "mode2"
	return flags;
}

pascal OSStatus OpenEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void *inUserData)
{
	NavDialogRef fileDialog;
	NavDialogCreationOptions fo;
	NavGetDefaultDialogCreationOptions(&fo);
	fo.optionFlags=0;
	fo.parentWindow=win;
	NavCreateChooseFileDialog(&fo,NULL,NULL,NULL,NULL,NULL,&fileDialog);
	if (!NavDialogRun(fileDialog)) {
		NavReplyRecord r;
		if (!NavDialogGetReply(fileDialog,&r)) {
			AEKeyword k;
			FSRef fr;
			if (!AEGetNthPtr(&r.selection,1,typeFSRef,&k,NULL,&fr,sizeof(fr),NULL)) {
				char file[255]="",*title="";
				FSRefMakePath(&fr,file,255);
				BASSMOD_MusicFree(); // free the current mod
				// load the MOD
				if (BASSMOD_MusicLoad(FALSE,file,0,0,GetFlags())) {
					// get the MOD length
					DWORD length=BASSMOD_MusicGetLength(0);
					SetControl32BitMaximum(GetControl(20),length-1);
					BASSMOD_MusicPlay();
					SetControlTitle(inUserData,file);
					title=BASSMOD_MusicGetName();
				} else { /* not a MOD */
					Error("Can't play the file");
					SetControlTitleWithCFString(inUserData,CFSTR("click here to open a file..."));
					SetControl32BitMaximum(GetControl(20),0);
				}
				ControlRef cref=GetControl(11);
				SetControlData(cref,kControlEntireControl,kControlStaticTextTextTag,strlen(title),title);
				DrawOneControl(cref);
				SetControl32BitValue(GetControl(20),0);
			}
			NavDisposeReply(&r);
		}
	}
	NavDialogDispose(fileDialog);
    return noErr;
}

pascal OSStatus PlayEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void *inUserData)
{
	BASSMOD_MusicPlay();
	return noErr;
}

pascal OSStatus PauseEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void *inUserData)
{
	BASSMOD_MusicPause();
	return noErr;
}

pascal OSStatus FlagsEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void *inUserData)
{
	BASSMOD_MusicPlayEx(-1,GetFlags(),FALSE); // update flags
	return noErr;
}

pascal void PosEventHandler(ControlHandle control, SInt16 part)
{
	DWORD p=GetControl32BitValue(control);
	if (p!=LOWORD(BASSMOD_MusicGetPosition()))
		BASSMOD_MusicSetPosition(p); // seek
}

pascal void TimerProc(EventLoopTimerRef inTimer, void *inUserData)
{	/* update "display" */
	char text[12];
	int pos=BASSMOD_MusicGetPosition();
	if (pos==-1) pos=0;
	else SetControl32BitValue(GetControl(20),LOWORD(pos));
	sprintf(text,"%03d.%03d",LOWORD(pos),HIWORD(pos));
	ControlRef cref=GetControl(15);
	SetControlData(cref,kControlEntireControl,kControlStaticTextTextTag,strlen(text),text);
	DrawOneControl(cref);
	sprintf(text,"%.1f%%",BASSMOD_GetCPU());
	cref=GetControl(16);
	SetControlData(cref,kControlEntireControl,kControlStaticTextTextTag,strlen(text),text);
	DrawOneControl(cref);
}

int main(int argc, char* argv[])
{
	IBNibRef 		nibRef;
	OSStatus		err;
    
	InitCursor();

	// Check that BASSMOD 2.0 was loaded
	if (BASSMOD_GetVersion()!=MAKELONG(2,0)) {
		Error("BASSMOD version 2.0 was not loaded");
		return 0;
	}

	// setup output - default device, 44100hz, stereo, 16 bits
	if (!BASSMOD_Init(-1,44100,BASS_DEVICE_NOSYNC)) {
		Error("Can't initialize device");
		return 0;
	}
	
	// Create Window and stuff
	err = CreateNibReference(CFSTR("modtest"), &nibRef);
	if (err) return err;
	err = CreateWindowFromNib(nibRef, CFSTR("Window"), &win);
	if (err) return err;
	DisposeNibReference(nibRef);

	SetupControlHandler(10,kEventControlHit,OpenEventHandler);
	SetupControlHandler(12,kEventControlHit,PlayEventHandler);
	SetupControlHandler(13,kEventControlHit,PauseEventHandler);
	SetControlAction(GetControl(20),NewControlActionUPP(PosEventHandler));
	SetupControlHandler(21,kEventControlValueFieldChanged,FlagsEventHandler);
	SetupControlHandler(22,kEventControlValueFieldChanged,FlagsEventHandler);
	SetupControlHandler(23,kEventControlValueFieldChanged,FlagsEventHandler);

	EventLoopTimerRef timer;
	InstallEventLoopTimer(GetCurrentEventLoop(),kEventDurationNoWait,kEventDurationSecond/10,TimerProc,0,&timer);

	ShowWindow(win);
	RunApplicationEventLoop();

	BASSMOD_Free();

    return 0; 
}
