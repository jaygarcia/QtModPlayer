/*
 * XimpleMOD --- module player for Mac OS X
 * deprecated.c
 *
 * 2005 by Marco Trillo <toad@arsystel.com>
 *
 * This program is free software; under Public Domain. You can use it as you want.
 * You can redistribute and modify it, even with commercial intentions.
 *
 * This software is provided "as is", WITHOUT ANY WARRANTY,
 * either expressed or implied, including but not limited to the implied
 * warranties of merchantability and/or fitness for a particular purpose.
 * The author shall NOT be held liable for ANY damage to you, your
 * computer, or to anyone or anything else, that may result from its use,
 * or misuse. Basically, you use it at YOUR OWN RISK.
 */

#include "bassmod.h"

/*
deprecated.c
These functions enable backward compatibility to BASSMOD 2.0 from BASSMOD 2.1
*/

DWORD BASSMOD_MusicGetVolume(DWORD chanins) {
	int thehiword;
	DWORD attrib;

	thehiword=HIWORD(chanins);
	if ( thehiword == 0 ) attrib=BASS_MUSIC_ATTRIB_VOL_CHAN+LOWORD(chanins);
	else attrib=BASS_MUSIC_ATTRIB_VOL_INST+LOWORD(chanins);
	
	return BASSMOD_MusicGetAttribute(attrib);
}

DWORD BASSMOD_MusicSetVolume(DWORD chanins,DWORD volume) {
	int thehiword;
	DWORD attrib;

	thehiword=HIWORD(chanins);
	if ( thehiword == 0 ) attrib=BASS_MUSIC_ATTRIB_VOL_CHAN+LOWORD(chanins);
	else attrib=BASS_MUSIC_ATTRIB_VOL_INST+LOWORD(chanins);
	
	return BASSMOD_MusicSetAttribute(attrib,volume);
}

